from django.urls import path, include
from rest_framework import routers
from .views import dashboard
from . import views
from django.db import connection

def sidebar_statistics(request):
    with connection.cursor() as cursor:
        cursor.execute("SELECT COUNT(*) FROM customers")
        total_customers = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM orders")
        total_orders = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM products")
        total_products = cursor.fetchone()[0]
        
        cursor.execute("SELECT SUM(amount_due) FROM invoices")
        total_revenue = cursor.fetchone()[0] or 0

    return {
        'total_customers': total_customers,
        'total_orders': total_orders,
        'total_products': total_products,
        'total_revenue': total_revenue
    }

urlpatterns = [
    path('', views.dashboard, name='dashboard'),
    path('top-customers/', views.top_customers_list, name='top_customers_list'),
    path('top-products-bar-data/', views.top_products_bar_data, name='top_products_bar_data'),
    path('api/monthly-profit/', views.monthly_profit_data, name='monthly_profit_data'),

]
