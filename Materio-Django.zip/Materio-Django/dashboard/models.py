from django.db import models
from django.shortcuts import render

from django.db.models import Count, Sum


def some_function():
    from dashboard.models import StudentTable

def dashboard_stats(request):
    total_students = StudentTable.objects.count()
    total_courses = CourseTable.objects.count()
    total_subjects = SubjectTable.objects.count()
    most_enrolled_subject = EnrollTable.objects.values('SubjCode').annotate(total=Count('SubjCode')).order_by('-total').first()
    total_units_per_student = EnrollTable.objects.values('StudentID').annotate(total_units=Sum('subjcode__Units'))

    return render(request, 'dashboard/stats.html', {
        'total_students': total_students,
        'total_courses': total_courses,
        'total_subjects': total_subjects,
        'most_enrolled_subject': most_enrolled_subject,
        'total_units_per_student': total_units_per_student,
    })

class CourseTable(models.Model):
    Course = models.CharField(max_length=45, primary_key=True)
    College = models.CharField(max_length=45)

    def __str__(self):
        return self.Course

class StudentTable(models.Model):
    StudentID = models.CharField(max_length=45, primary_key=True)
    Student_Name = models.CharField(max_length=45)
    Course = models.ForeignKey(CourseTable, on_delete=models.CASCADE, db_column='Course')

    def __str__(self):
        return self.Student_Name

class SubjectTable(models.Model):
    SubjCode = models.CharField(max_length=45, primary_key=True)
    SubjDescription = models.CharField(max_length=45)
    Units = models.IntegerField()

    def __str__(self):
        return self.SubjDescription

class EnrollTable(models.Model):
    StudentID = models.ForeignKey(StudentTable, on_delete=models.CASCADE, db_column='StudentID')
    SubjCode = models.ForeignKey(SubjectTable, on_delete=models.CASCADE, db_column='SubjCode')

    class Meta:
        unique_together = (('StudentID', 'SubjCode'),)

class ContactTable(models.Model):
    Contactid = models.CharField(max_length=45, primary_key=True)
    StudentID = models.ForeignKey(StudentTable, on_delete=models.CASCADE, db_column='StudentID')
    ContactNumber = models.CharField(max_length=45)

class SomeModel(models.Model):
    SubjCode = models.CharField(max_length=45)