from django.contrib import admin
from dashboard.models import StudentTable

# Register your models here.
