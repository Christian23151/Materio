def sidebar_statistics(request):
    return {'stats': 'Your sidebar stats here'}
