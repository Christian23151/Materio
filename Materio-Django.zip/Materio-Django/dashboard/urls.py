from django.urls import path, include
from rest_framework import routers
from .views import dashboard_stats
from . import views
from django.db import connection



urlpatterns = [
    path('', dashboard_stats, name='dashboard'),
    path('stats/', views.dashboard_stats, name='dashboard_stats'),

]
